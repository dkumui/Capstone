<script lang="ts">
	import { page } from '$app/state';

	let { children } = $props();

	const isLoginPage = $derived(page.url.pathname === '/admin/login');

	const navItems = [
		{ href: '/admin', label: 'Overview' },
		{ href: '/admin/company', label: 'Data Toko' },
		{ href: '/admin/products', label: 'Manajemen Produk' },
		{ href: '/admin/inventory', label: 'Log Stok' },
		{ href: '/admin/chats', label: 'Riwayat Chat' }
	];

	function isActive(href: string): boolean {
        const pathname = String(page.url.pathname);

        if (href === '/admin') {
            return pathname === '/admin';
        }

        return pathname.startsWith(href);
    }
</script>

{#if isLoginPage}
	{@render children()}
{:else}
	<div class="min-h-screen bg-[#f8f1e7]">
		<div class="mx-auto flex w-full max-w-7xl gap-6 px-4 py-6 md:px-6">
			<aside class="hidden w-64 shrink-0 md:block">
				<div class="sticky top-6 rounded-2xl border border-[#e2d1ba] bg-white p-4 shadow-sm">
					<p class="text-xs font-semibold uppercase tracking-wide text-[#9f7a5a]">
						Admin Panel
					</p>

					<h1 class="mt-1 text-xl font-bold text-[var(--color-brown)]">
						Batik HM Akmal
					</h1>

					<nav class="mt-6 space-y-2 text-sm">
						{#each navItems as item}
							<a
								class={isActive(item.href)
									? 'block rounded-lg bg-[#6a2a2a] px-3 py-2 font-semibold text-white'
									: 'block rounded-lg px-3 py-2 text-[#4a3425] hover:bg-[#f4eadf]'}
								href={item.href}
							>
								{item.label}
							</a>
						{/each}
					</nav>

					<form method="POST" action="/admin/logout" class="mt-6">
						<button class="btn-secondary w-full" type="submit">Logout</button>
					</form>
				</div>
			</aside>

			<main class="min-w-0 flex-1">
				<div class="mb-5 rounded-2xl border border-[#e2d1ba] bg-white p-3 md:hidden">
					<div class="flex items-center justify-between gap-3">
						<div>
							<p class="text-xs font-semibold uppercase tracking-wide text-[#9f7a5a]">
								Admin Panel
							</p>
							<p class="font-bold text-[var(--color-brown)]">Batik HM Akmal</p>
						</div>

						<form method="POST" action="/admin/logout">
							<button class="btn-secondary px-3 py-2 text-xs" type="submit">Logout</button>
						</form>
					</div>

					<div class="mt-3 flex gap-2 overflow-x-auto pb-1 text-sm">
						{#each navItems as item}
							<a
								class={isActive(item.href)
									? 'shrink-0 rounded-lg bg-[#6a2a2a] px-3 py-2 font-semibold text-white'
									: 'shrink-0 rounded-lg bg-[#f4eadf] px-3 py-2 text-[#4a3425]'}
								href={item.href}
							>
								{item.label}
							</a>
						{/each}
					</div>
				</div>

				{@render children()}
			</main>
		</div>
	</div>
{/if}