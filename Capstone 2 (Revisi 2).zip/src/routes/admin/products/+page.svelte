<script lang="ts">
	import { formatRupiah } from '$lib/utils/format';
	import type { ActionData, PageData } from './$types';

	let { data, form }: { data: PageData; form: ActionData } = $props();

	let search = $state('');
	let capFilter = $state<'all' | 'cap_1_warna' | 'cap_2_warna'>('all');
	let statusFilter = $state<'all' | 'active' | 'inactive'>('all');

	const filteredProducts = $derived.by(() => {
		return data.products.filter((product) => {
			const keyword = search.toLowerCase().trim();

			const keywordOk =
				keyword.length === 0 ||
				product.name.toLowerCase().includes(keyword) ||
				product.product_code.toLowerCase().includes(keyword) ||
				product.color_variant.toLowerCase().includes(keyword);

			const capOk = capFilter === 'all' || product.cap_type === capFilter;

			const statusOk =
				statusFilter === 'all' ||
				(statusFilter === 'active' && product.is_active) ||
				(statusFilter === 'inactive' && !product.is_active);

			return keywordOk && capOk && statusOk;
		});
	});

	function capLabel(cap: string): string {
		return cap === 'cap_1_warna' ? 'Cap 1 Warna' : 'Cap 2 Warna';
	}

	function stockLabel(stock: string): string {
		if (stock === 'ready') return 'Ready';
		if (stock === 'limited') return 'Terbatas';
		if (stock === 'sold_out') return 'Habis';
		return 'Cek Stok';
	}

	function stockBadgeClass(stock: string): string {
		if (stock === 'ready') return 'bg-green-100 text-green-800 border-green-200';
		if (stock === 'limited') return 'bg-yellow-100 text-yellow-800 border-yellow-200';
		if (stock === 'sold_out') return 'bg-red-100 text-red-800 border-red-200';
		return 'bg-stone-100 text-stone-700 border-stone-200';
	}

	function productImage(src: string | null | undefined): string {
		return src && src.trim() !== '' ? src : '/placeholder-batik.svg';
	}
</script>

<svelte:head>
	<title>Manajemen Produk | Admin Batik HM Akmal</title>
</svelte:head>

<section class="space-y-6">
	<div>
		<h1 class="text-3xl font-bold text-[var(--color-brown)]">Manajemen Produk</h1>
		<p class="mt-2 text-sm text-[#6a5340]">
			Tambah produk, edit detail, upload foto, ubah stok, aktifkan, sembunyikan, atau hapus produk.
		</p>
	</div>

	{#if form?.message}
		<div class="rounded-xl border border-[#d8c3aa] bg-white px-4 py-3 text-sm text-[var(--color-brown)]">
			{form.message}
		</div>
	{/if}

	<section class="rounded-2xl border border-[#e2d1ba] bg-white p-5">
		<h2 class="text-xl font-semibold text-[var(--color-brown)]">Tambah Produk</h2>

		<form method="POST" action="?/createProduct" class="mt-5 grid gap-4 md:grid-cols-2">
			<label class="text-sm text-[#6e5846]">
				Kode Produk
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="product_code" placeholder="Contoh: HM-C1-008" required />
			</label>

			<label class="text-sm text-[#6e5846]">
				Nama Produk
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="name" placeholder="Contoh: Cap 1 Warna Hitam" />
			</label>

			<label class="text-sm text-[#6e5846]">
				Jenis Cap
				<select class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="cap_type">
					<option value="cap_1_warna">Cap 1 Warna</option>
					<option value="cap_2_warna">Cap 2 Warna</option>
				</select>
			</label>

			<label class="text-sm text-[#6e5846]">
				Varian Warna
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="color_variant" placeholder="Contoh: Hitam" required />
			</label>

			<label class="text-sm text-[#6e5846]">
				Panjang CM
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_length_cm" type="number" value="205" />
			</label>

			<label class="text-sm text-[#6e5846]">
				Lebar CM
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_width_cm" type="number" value="110" />
			</label>

			<label class="text-sm text-[#6e5846]">
				Catatan Ukuran
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_note" value="Kurang lebih 205 x 110 cm" />
			</label>

			<label class="text-sm text-[#6e5846]">
				Harga
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="price" type="number" min="0" placeholder="58000" required />
			</label>

			<label class="text-sm text-[#6e5846]">
				Stok
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="stock_qty" type="number" min="0" placeholder="Kosongkan jika cek stok" />
			</label>

			<label class="text-sm text-[#6e5846]">
				URL Gambar
				<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="image_url" placeholder="/placeholder-batik.svg" />
			</label>

			<label class="text-sm text-[#6e5846] md:col-span-2">
				Deskripsi
				<textarea class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="description" rows="3"></textarea>
			</label>

			<div class="flex flex-wrap gap-4 text-sm text-[#6e5846] md:col-span-2">
				<label class="inline-flex items-center gap-2">
					<input name="is_featured" type="checkbox" />
					Produk unggulan
				</label>

				<label class="inline-flex items-center gap-2">
					<input name="is_active" type="checkbox" checked />
					Tampilkan di katalog
				</label>
			</div>

			<div class="md:col-span-2">
				<button class="btn-primary" type="submit">Simpan Produk</button>
			</div>
		</form>
	</section>

	<section class="rounded-2xl border border-[#e2d1ba] bg-white p-5">
		<div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
			<div>
				<h2 class="text-xl font-semibold text-[var(--color-brown)]">CRUD Produk</h2>
				<p class="mt-1 text-sm text-[#6c5543]">
					Semua produk tampil di sini, termasuk produk yang disembunyikan.
				</p>
			</div>

			<div class="grid gap-2 sm:grid-cols-3">
				<input class="rounded-lg border border-[#dbc7af] px-3 py-2 text-sm" bind:value={search} placeholder="Cari produk..." />

				<select class="rounded-lg border border-[#dbc7af] px-3 py-2 text-sm" bind:value={capFilter}>
					<option value="all">Semua Jenis</option>
					<option value="cap_1_warna">Cap 1 Warna</option>
					<option value="cap_2_warna">Cap 2 Warna</option>
				</select>

				<select class="rounded-lg border border-[#dbc7af] px-3 py-2 text-sm" bind:value={statusFilter}>
					<option value="all">Semua Status</option>
					<option value="active">Aktif</option>
					<option value="inactive">Disembunyikan</option>
				</select>
			</div>
		</div>

		{#if filteredProducts.length === 0}
			<p class="mt-4 rounded-xl bg-[#faf3ea] px-4 py-3 text-sm text-[#6f5946]">
				Tidak ada produk sesuai filter.
			</p>
		{:else}
			<div class="mt-5 space-y-4">
				{#each filteredProducts as product}
					<article class="rounded-xl border border-[#eadac7] bg-[#fffaf3] p-4">
						<div class="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
							<div class="flex gap-4">
								<img src={productImage(product.image_url)} alt={product.name} class="h-24 w-24 rounded-lg border border-[#eadac7] object-cover" />

								<div>
									<p class="font-mono text-xs text-[#7a634f]">{product.product_code}</p>
									<h3 class="mt-1 text-lg font-semibold text-[#4a3425]">{product.name}</h3>
									<p class="mt-1 text-sm text-[#6e5846]">
										{capLabel(product.cap_type)} • {product.color_variant} • {formatRupiah(product.price)}
									</p>
									<p class="mt-1 text-sm text-[#6e5846]">
										Ukuran: {product.size_note ?? `Kurang lebih ${product.size_length_cm} x ${product.size_width_cm} cm`}
									</p>

									<div class="mt-2 flex flex-wrap gap-2">
										<span class={`inline-flex rounded-full border px-2 py-1 text-xs font-semibold ${stockBadgeClass(product.stock_status)}`}>
											{stockLabel(product.stock_status)}
										</span>

										<span class="inline-flex rounded-full border border-[#e2d1ba] bg-white px-2 py-1 text-xs font-semibold text-[#6e5846]">
											{product.is_active ? 'Aktif' : 'Disembunyikan'}
										</span>

										{#if product.is_featured}
											<span class="inline-flex rounded-full border border-[#e2d1ba] bg-white px-2 py-1 text-xs font-semibold text-[#6e5846]">
												Unggulan
											</span>
										{/if}
									</div>
								</div>
							</div>

							<div class="flex min-w-48 flex-col gap-2">
								<form method="POST" action="?/updateStock" class="flex gap-2">
									<input type="hidden" name="product_code" value={product.product_code} />
									<input class="w-24 rounded-lg border border-[#dbc7af] px-2 py-1 text-sm" name="stock_qty" type="number" min="0" value={product.stock_qty ?? ''} placeholder="Cek" />
									<button class="btn-secondary px-3 py-1 text-xs" type="submit">Update Stok</button>
								</form>

								<form method="POST" action="?/toggleActive">
									<input type="hidden" name="product_code" value={product.product_code} />
									<input type="hidden" name="next_active" value={product.is_active ? 'false' : 'true'} />
									<button class="btn-secondary w-full px-3 py-1 text-xs" type="submit">
										{product.is_active ? 'Sembunyikan Produk' : 'Aktifkan Produk'}
									</button>
								</form>

								<form method="POST" action="?/deleteProduct">
									<input type="hidden" name="product_code" value={product.product_code} />
									<button class="w-full rounded-lg border border-red-300 bg-white px-3 py-2 text-xs font-semibold text-red-700" type="submit">
										Hapus Produk
									</button>
								</form>
							</div>
						</div>

						<div class="mt-4 grid gap-4 lg:grid-cols-[220px_1fr]">
							<form method="POST" action="?/uploadProductImage" enctype="multipart/form-data" class="rounded-lg border border-[#eadac7] bg-white p-3">
								<input type="hidden" name="product_code" value={product.product_code} />

								<label class="text-sm text-[#6e5846]">
									Upload Foto
									<input class="mt-2 block w-full text-xs text-[#6e5846]" name="image_file" type="file" accept="image/png,image/jpeg,image/webp" required />
								</label>

								<button class="btn-secondary mt-3 w-full px-3 py-1 text-xs" type="submit">Upload</button>
							</form>

							<details class="rounded-lg border border-[#eadac7] bg-white p-3">
								<summary class="cursor-pointer text-sm font-semibold text-[var(--color-maroon)]">
									Edit detail produk
								</summary>

								<form method="POST" action="?/updateProduct" class="mt-4 grid gap-3 md:grid-cols-3">
									<input type="hidden" name="product_code" value={product.product_code} />

									<label class="text-sm text-[#6e5846]">
										Nama Produk
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="name" value={product.name} required />
									</label>

									<label class="text-sm text-[#6e5846]">
										Jenis Cap
										<select class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="cap_type">
											<option value="cap_1_warna" selected={product.cap_type === 'cap_1_warna'}>Cap 1 Warna</option>
											<option value="cap_2_warna" selected={product.cap_type === 'cap_2_warna'}>Cap 2 Warna</option>
										</select>
									</label>

									<label class="text-sm text-[#6e5846]">
										Varian Warna
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="color_variant" value={product.color_variant} required />
									</label>

									<label class="text-sm text-[#6e5846]">
										Panjang CM
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_length_cm" type="number" value={product.size_length_cm} />
									</label>

									<label class="text-sm text-[#6e5846]">
										Lebar CM
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_width_cm" type="number" value={product.size_width_cm} />
									</label>

									<label class="text-sm text-[#6e5846]">
										Catatan Ukuran
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="size_note" value={product.size_note ?? 'Kurang lebih 205 x 110 cm'} />
									</label>

									<label class="text-sm text-[#6e5846]">
										Harga
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="price" type="number" min="0" value={product.price} required />
									</label>

									<label class="text-sm text-[#6e5846]">
										Stok
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="stock_qty" type="number" min="0" value={product.stock_qty ?? ''} />
									</label>

									<label class="text-sm text-[#6e5846]">
										URL Gambar
										<input class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="image_url" value={product.image_url ?? ''} />
									</label>

									<label class="text-sm text-[#6e5846] md:col-span-3">
										Deskripsi
										<textarea class="mt-1 w-full rounded-lg border border-[#dbc7af] px-3 py-2" name="description" rows="3">{product.description ?? ''}</textarea>
									</label>

									<div class="flex flex-wrap gap-4 text-sm text-[#6e5846] md:col-span-3">
										<label class="inline-flex items-center gap-2">
											<input name="is_featured" type="checkbox" checked={product.is_featured} />
											Produk unggulan
										</label>

										<label class="inline-flex items-center gap-2">
											<input name="is_active" type="checkbox" checked={product.is_active} />
											Tampilkan di katalog
										</label>
									</div>

									<div class="md:col-span-3">
										<button class="btn-primary" type="submit">Simpan Perubahan Produk</button>
									</div>
								</form>
							</details>
						</div>
					</article>
				{/each}
			</div>
		{/if}
	</section>
</section>