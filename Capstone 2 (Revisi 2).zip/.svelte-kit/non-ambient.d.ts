
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/admin" | "/admin/chats" | "/admin/chats/[sessionId]" | "/admin/company" | "/admin/inventory" | "/admin/login" | "/admin/logout" | "/admin/products" | "/api" | "/api/cashier" | "/api/cashier/stock" | "/api/chat" | "/products" | "/products/[slug]";
		RouteParams(): {
			"/admin/chats/[sessionId]": { sessionId: string };
			"/products/[slug]": { slug: string }
		};
		LayoutParams(): {
			"/": { sessionId?: string | undefined; slug?: string | undefined };
			"/admin": { sessionId?: string | undefined };
			"/admin/chats": { sessionId?: string | undefined };
			"/admin/chats/[sessionId]": { sessionId: string };
			"/admin/company": Record<string, never>;
			"/admin/inventory": Record<string, never>;
			"/admin/login": Record<string, never>;
			"/admin/logout": Record<string, never>;
			"/admin/products": Record<string, never>;
			"/api": Record<string, never>;
			"/api/cashier": Record<string, never>;
			"/api/cashier/stock": Record<string, never>;
			"/api/chat": Record<string, never>;
			"/products": { slug?: string | undefined };
			"/products/[slug]": { slug: string }
		};
		Pathname(): "/" | "/admin" | "/admin/chats" | `/admin/chats/${string}` & {} | "/admin/company" | "/admin/inventory" | "/admin/login" | "/admin/logout" | "/admin/products" | "/api/cashier/stock" | "/api/chat" | `/products/${string}` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/placeholder-batik.svg" | "/robots.txt" | string & {};
	}
}